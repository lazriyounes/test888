from django.urls import path
from . import views
urlpatterns =[   
    path('/0' ,views.index , name='index'),
     path('/wilaya' ,views.second , name='second'),
      path('/update<int:id>' ,views.update , name='update'),
       path('/update2<int:id>' ,views.update2 , name='update2'),
       path('/delete<int:id>' ,views.delete , name='delete'),

]
