from django.contrib import admin
from .models import Produit,Categoryprod,Wilaya ,Checkbox
# Register your models here.
admin.site.register(Wilaya),
admin.site.register(Categoryprod),
admin.site.register(Produit),

admin.site.register(Checkbox),